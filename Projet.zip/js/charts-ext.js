/* ============================================================
   TANDOR — charts-ext.js
   Extra SVG chart primitives for the analysis pages, tuned to the
   same light "market desk" system as app-charts.js. No libraries.
   Entrance animation is gated by CSS (prefers-reduced-motion safe).
   ============================================================ */
(function () {
  'use strict';
  const SVGNS = 'http://www.w3.org/2000/svg';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const Tip = () => window.Tip;

  function el(tag, attrs, parent) {
    const n = document.createElementNS(SVGNS, tag);
    if (attrs) for (const k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function smoothPath(pts) {
    if (pts.length < 2) return pts.length ? `M ${pts[0][0]},${pts[0][1]}` : '';
    let d = `M ${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += ` C ${c1x},${c1y} ${c2x},${c2y} ${p2[0]},${p2[1]}`;
    }
    return d;
  }
  const uid = () => 'cx' + Math.random().toString(36).slice(2, 8);
  const RM = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  // Entrance reveal intentionally a no-op: transform/opacity-from-hidden
  // freezes invisible when the iframe throttles its animation timeline,
  // and breaks html-to-image/PDF capture. Charts render in their final
  // state; the only animated primitive is the line-draw (which reverts to
  // a plain stroke on completion).
  function reveal() {}

  /* ============================================================
     MULTI-SERIES LINE / AREA  (Trends, composite signals)
     series: [{ name, color, values:[], fill? }]
     opts: { xlabels:[], yMax, yMin, area, height, crosshair }
     ============================================================ */
  function lineChart(container, series, opts) {
    container.innerHTML = '';
    const o = Object.assign({ area: true, crosshair: true, yMin: 0, yMax: 100, fmtY: (v) => Math.round(v), fmtTip: (v) => Math.round(v), unit: '' }, opts || {});
    const W = container.clientWidth || 640, H = o.height || container.clientHeight || 280;
    const m = { t: 14, r: 16, b: 26, l: 34 };
    const pw = W - m.l - m.r, ph = H - m.t - m.b;
    const n = series[0].values.length;
    const xMin = o.yMin, xMax = o.yMax;
    const X = (i) => m.l + (n <= 1 ? 0 : (i / (n - 1)) * pw);
    const Y = (v) => m.t + (1 - (v - xMin) / (xMax - xMin || 1)) * ph;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'lc-svg' });
    container.appendChild(svg);

    // y gridlines
    const ticks = 4;
    for (let t = 0; t <= ticks; t++) {
      const v = xMin + (t / ticks) * (xMax - xMin);
      const y = Y(v);
      el('line', { x1: m.l, y1: y, x2: m.l + pw, y2: y, stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg);
      const tx = el('text', { x: m.l - 7, y: y + 3, class: 'lc-axis', 'text-anchor': 'end' }, svg);
      tx.textContent = o.fmtY(v);
    }
    // x labels (sparse)
    if (o.xlabels) {
      const step = Math.ceil(n / 6);
      o.xlabels.forEach((lab, i) => { if (i % step === 0 || i === n - 1) { const tx = el('text', { x: X(i), y: H - 7, class: 'lc-axis', 'text-anchor': 'middle' }, svg); tx.textContent = lab; } });
    }
    // series
    series.forEach((s) => {
      const pts = s.values.map((v, i) => [X(i), Y(v)]);
      const line = smoothPath(pts);
      if (o.area && s.fill !== false) {
        const gid = uid();
        const defs = el('defs', {}, svg);
        const lg = el('linearGradient', { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
        el('stop', { offset: '0%', 'stop-color': s.color, 'stop-opacity': '.16' }, lg);
        el('stop', { offset: '100%', 'stop-color': s.color, 'stop-opacity': '0' }, lg);
        el('path', { d: `${line} L ${pts[pts.length - 1][0]},${m.t + ph} L ${pts[0][0]},${m.t + ph} Z`, fill: `url(#${gid})` }, svg);
      }
      const path = el('path', { d: line, fill: 'none', stroke: s.color, 'stroke-width': 2.2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', class: 'lc-line' }, svg);
      if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        const len = path.getTotalLength ? path.getTotalLength() : pw * 1.4;
        path.style.strokeDasharray = len;
        path.style.setProperty('--len', len + 'px');
        path.style.strokeDashoffset = '0';
        path.style.animation = 'lcDraw .8s cubic-bezier(.22,1,.36,1)';
        const clear = () => { path.style.strokeDasharray = 'none'; path.style.strokeDashoffset = '0'; path.style.animation = ''; };
        path.addEventListener('animationend', clear, { once: true });
        setTimeout(clear, 1000);
      }
    });
    // crosshair + hover
    if (o.crosshair) {
      const cl = el('line', { x1: 0, y1: m.t, x2: 0, y2: m.t + ph, stroke: 'var(--border-strong)', 'stroke-width': 1, 'stroke-dasharray': '3 3', opacity: 0 }, svg);
      const dots = series.map((s) => el('circle', { r: 3.4, fill: s.color, stroke: 'var(--surface-1)', 'stroke-width': 1.5, opacity: 0 }, svg));
      const hit = el('rect', { x: m.l, y: m.t, width: pw, height: ph, fill: 'transparent' }, svg);
      hit.addEventListener('mousemove', (e) => {
        const rect = svg.getBoundingClientRect();
        const rel = (e.clientX - rect.left) / rect.width * W;
        let i = Math.round(((rel - m.l) / pw) * (n - 1)); i = clamp(i, 0, n - 1);
        const xx = X(i);
        cl.setAttribute('x1', xx); cl.setAttribute('x2', xx); cl.setAttribute('opacity', 1);
        dots.forEach((d, si) => { d.setAttribute('cx', xx); d.setAttribute('cy', Y(series[si].values[i])); d.setAttribute('opacity', 1); });
        const rows = series.map((s) => `<div><span style="color:${s.color}">●</span> ${s.name}<b>${o.fmtTip(s.values[i])}${o.unit}</b></div>`).join('');
        Tip() && Tip().show(`<div class="tip-h"><b>${o.xlabels ? o.xlabels[i] : i}</b></div><div class="tip-rows">${rows}</div>`, e);
      });
      hit.addEventListener('mouseleave', () => { cl.setAttribute('opacity', 0); dots.forEach((d) => d.setAttribute('opacity', 0)); Tip() && Tip().hide(); });
    }
    return svg;
  }

  /* ============================================================
     BAR CHART  (Reddit mentions, distributions)
     ============================================================ */
  function barChart(container, values, opts) {
    container.innerHTML = '';
    const o = Object.assign({ color: 'var(--reddit)', xlabels: null, height: null, fmtTip: (v) => v, onBar: null, line: false }, opts || {});
    const W = container.clientWidth || 600, H = o.height || container.clientHeight || 200;
    const m = { t: 12, r: 12, b: 24, l: 30 };
    const pw = W - m.l - m.r, ph = H - m.t - m.b;
    const n = values.length, max = Math.max(...values, 1);
    const gap = Math.min(8, pw / n * 0.32), bw = (pw - gap * (n - 1)) / n;
    const X = (i) => m.l + i * (bw + gap);
    const Y = (v) => m.t + (1 - v / max) * ph;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'bc-svg' });
    container.appendChild(svg);
    [0, 0.5, 1].forEach((t) => { const y = m.t + (1 - t) * ph; el('line', { x1: m.l, y1: y, x2: m.l + pw, y2: y, stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg); const tx = el('text', { x: m.l - 7, y: y + 3, class: 'lc-axis', 'text-anchor': 'end' }, svg); tx.textContent = Math.round(max * t); });
    values.forEach((v, i) => {
      const bh = Math.max(1, (v / max) * ph), x = X(i), y = m.t + ph - bh;
      const g = el('g', { class: 'bc-bar' }, svg);
      const rect = el('rect', { x, y, width: bw, height: bh, rx: Math.min(3, bw / 3), fill: o.color, 'fill-opacity': (0.45 + 0.45 * (v / max)).toFixed(2) }, g);
      reveal(g, [{ transform: 'scaleY(0)' }, { transform: 'none' }], i);
      g.style.cursor = o.onBar ? 'pointer' : 'default';
      g.addEventListener('mouseenter', (e) => { rect.setAttribute('fill-opacity', '1'); Tip() && Tip().show(`<div class="tip-h"><b>${o.xlabels ? o.xlabels[i] : '#' + (i + 1)}</b></div><div class="tip-rows"><div><span>${o.label || ''}</span><b>${o.fmtTip(v)}</b></div></div>`, e); });
      g.addEventListener('mousemove', (e) => Tip() && Tip().move(e));
      g.addEventListener('mouseleave', () => { rect.setAttribute('fill-opacity', (0.45 + 0.45 * (v / max)).toFixed(2)); Tip() && Tip().hide(); });
      if (o.onBar) g.addEventListener('click', () => o.onBar(i));
    });
    if (o.line) {
      const pts = values.map((v, i) => [X(i) + bw / 2, Y(v)]);
      el('path', { d: smoothPath(pts), fill: 'none', stroke: 'var(--text-tertiary)', 'stroke-width': 1.6, 'stroke-dasharray': '4 3', opacity: .8 }, svg);
    }
    if (o.xlabels) { const step = Math.ceil(n / 8); o.xlabels.forEach((lab, i) => { if (i % step === 0 || i === n - 1) { const tx = el('text', { x: X(i) + bw / 2, y: H - 7, class: 'lc-axis', 'text-anchor': 'middle' }, svg); tx.textContent = lab; } }); }
    return svg;
  }

  /* ============================================================
     DIVERGING AREA  (acceleration: above/below 0)
     ============================================================ */
  function divergingArea(container, values, opts) {
    container.innerHTML = '';
    const o = Object.assign({ posColor: 'var(--buy)', negColor: 'var(--ph-mature)', xlabels: null, height: null }, opts || {});
    const W = container.clientWidth || 600, H = o.height || container.clientHeight || 180;
    const m = { t: 12, r: 12, b: 22, l: 30 };
    const pw = W - m.l - m.r, ph = H - m.t - m.b;
    const n = values.length, amax = Math.max(...values.map(Math.abs), 0.01);
    const X = (i) => m.l + (i / (n - 1)) * pw;
    const Y = (v) => m.t + ph / 2 - (v / amax) * (ph / 2);
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'da-svg' });
    container.appendChild(svg);
    const zeroY = m.t + ph / 2;
    const pts = values.map((v, i) => [X(i), Y(v)]);
    const line = smoothPath(pts);
    const gpos = uid(), gneg = uid();
    const defs = el('defs', {}, svg);
    const lp = el('linearGradient', { id: gpos, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
    el('stop', { offset: '0%', 'stop-color': o.posColor, 'stop-opacity': '.28' }, lp);
    el('stop', { offset: '100%', 'stop-color': o.posColor, 'stop-opacity': '0' }, lp);
    const ln = el('linearGradient', { id: gneg, x1: 0, y1: 1, x2: 0, y2: 0 }, defs);
    el('stop', { offset: '0%', 'stop-color': o.negColor, 'stop-opacity': '.24' }, ln);
    el('stop', { offset: '100%', 'stop-color': o.negColor, 'stop-opacity': '0' }, ln);
    // clip above / below zero
    const cpA = uid(), cpB = uid();
    el('clipPath', { id: cpA }, defs).appendChild(el('rect', { x: 0, y: 0, width: W, height: zeroY }));
    el('clipPath', { id: cpB }, defs).appendChild(el('rect', { x: 0, y: zeroY, width: W, height: H - zeroY }));
    const areaPath = `${line} L ${pts[n - 1][0]},${zeroY} L ${pts[0][0]},${zeroY} Z`;
    el('path', { d: areaPath, fill: `url(#${gpos})`, 'clip-path': `url(#${cpA})` }, svg);
    el('path', { d: areaPath, fill: `url(#${gneg})`, 'clip-path': `url(#${cpB})` }, svg);
    el('line', { x1: m.l, y1: zeroY, x2: m.l + pw, y2: zeroY, stroke: 'var(--border-strong)', 'stroke-width': 1 }, svg);
    el('path', { d: line, fill: 'none', stroke: 'var(--text-secondary)', 'stroke-width': 1.8, 'stroke-linecap': 'round' }, svg);
    // hover dots
    const cl = el('circle', { r: 3.4, fill: 'var(--text-primary)', opacity: 0 }, svg);
    const hit = el('rect', { x: m.l, y: m.t, width: pw, height: ph, fill: 'transparent' }, svg);
    hit.addEventListener('mousemove', (e) => {
      const rect = svg.getBoundingClientRect(); const rel = (e.clientX - rect.left) / rect.width * W;
      let i = clamp(Math.round(((rel - m.l) / pw) * (n - 1)), 0, n - 1);
      cl.setAttribute('cx', X(i)); cl.setAttribute('cy', Y(values[i])); cl.setAttribute('opacity', 1);
      const v = values[i], lbl = v >= 0 ? (o.posLabel || '↑') : (o.negLabel || '↓');
      Tip() && Tip().show(`<div class="tip-h"><b>${o.xlabels ? o.xlabels[i] : '#' + i}</b><span class="tip-score" style="color:${v >= 0 ? o.posColor : o.negColor}">${lbl}</span></div><div class="tip-rows"><div><span>${o.label || 'Accel.'}</span><b>${v >= 0 ? '+' : ''}${v.toFixed(2)}</b></div></div>`, e);
    });
    hit.addEventListener('mouseleave', () => { cl.setAttribute('opacity', 0); Tip() && Tip().hide(); });
    return svg;
  }

  /* ============================================================
     SCATTER  (velocity × level, Market Signals)
     points: [{ x, y, r, color, label, meta }]
     ============================================================ */
  function scatter(container, points, opts) {
    container.innerHTML = '';
    const o = Object.assign({ xMax: 100, yMax: 100, xlabel: '', yLabel: '', height: null, quad: true, onPoint: null }, opts || {});
    const W = container.clientWidth || 600, H = o.height || container.clientHeight || 320;
    const m = { t: 16, r: 16, b: 28, l: 34 };
    const pw = W - m.l - m.r, ph = H - m.t - m.b;
    const X = (v) => m.l + (v / o.xMax) * pw;
    const Y = (v) => m.t + (1 - v / o.yMax) * ph;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'sc-svg' });
    container.appendChild(svg);
    if (o.quad) el('rect', { x: m.l, y: m.t, width: pw / 2, height: ph / 2, fill: 'var(--signal)', 'fill-opacity': '.05', rx: 6 }, svg);
    [25, 50, 75].forEach((g) => {
      el('line', { x1: X(g), y1: m.t, x2: X(g), y2: m.t + ph, stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg);
      el('line', { x1: m.l, y1: Y(g), x2: m.l + pw, y2: Y(g), stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg);
    });
    el('line', { x1: X(50), y1: m.t, x2: X(50), y2: m.t + ph, stroke: 'var(--border-strong)', 'stroke-width': 1, 'stroke-dasharray': '3 3' }, svg);
    el('line', { x1: m.l, y1: Y(50), x2: m.l + pw, y2: Y(50), stroke: 'var(--border-strong)', 'stroke-width': 1, 'stroke-dasharray': '3 3' }, svg);
    const ax = el('text', { x: m.l + pw / 2, y: H - 6, class: 'radar-axis', 'text-anchor': 'middle' }, svg); ax.textContent = o.xLabel + ' →';
    const ay = el('text', { x: 9, y: m.t + ph / 2, class: 'radar-axis', 'text-anchor': 'middle', transform: `rotate(-90 9 ${m.t + ph / 2})` }, svg); ay.textContent = o.yLabel + ' →';
    points.forEach((p, i) => {
      const cx = X(p.x), cy = Y(p.y), r = p.r || 7;
      const g = el('g', { class: 'sc-pt' }, svg);
      el('circle', { cx, cy, r: r + 3, fill: p.color, 'fill-opacity': '.12' }, g);
      const dot = el('circle', { cx, cy, r, fill: p.color, 'fill-opacity': '.72', stroke: p.color, 'stroke-width': 1.4 }, g);
      reveal(g, [{ opacity: 0, transform: 'scale(.6)' }, { opacity: 1, transform: 'none' }], i);
      g.style.cursor = o.onPoint ? 'pointer' : 'default';
      g.addEventListener('mouseenter', (e) => { dot.setAttribute('fill-opacity', '.95'); Tip() && Tip().show(p.tip || `<div class="tip-h"><b>${p.label}</b></div>`, e); });
      g.addEventListener('mousemove', (e) => Tip() && Tip().move(e));
      g.addEventListener('mouseleave', () => { dot.setAttribute('fill-opacity', '.72'); Tip() && Tip().hide(); });
      if (o.onPoint) g.addEventListener('click', () => o.onPoint(p));
    });
    return svg;
  }

  /* ============================================================
     DONUT  (phase distribution)
     segs: [{ value, color, label }]
     ============================================================ */
  function donut(container, segs, opts) {
    container.innerHTML = '';
    const o = Object.assign({ size: 180, thickness: 22, center: '' }, opts || {});
    const total = segs.reduce((s, d) => s + d.value, 0) || 1;
    const size = o.size, rOut = size / 2, rIn = rOut - o.thickness, cx = size / 2;
    const svg = el('svg', { viewBox: `0 0 ${size} ${size}`, width: size, height: size, class: 'dn-svg' });
    container.appendChild(svg);
    const gap = 0.02; // radian gap between wedges (filled paths render in html-to-image/PDF)
    const arcPath = (a0, a1) => {
      const p = (r, a) => [cx + r * Math.cos(a), cx + r * Math.sin(a)];
      const large = (a1 - a0) > Math.PI ? 1 : 0;
      const [x0, y0] = p(rOut, a0), [x1, y1] = p(rOut, a1), [x2, y2] = p(rIn, a1), [x3, y3] = p(rIn, a0);
      return `M${x0},${y0} A${rOut},${rOut} 0 ${large} 1 ${x1},${y1} L${x2},${y2} A${rIn},${rIn} 0 ${large} 0 ${x3},${y3} Z`;
    };
    let a = -Math.PI / 2;
    segs.forEach((sg) => {
      const frac = sg.value / total, a1 = a + frac * Math.PI * 2;
      const wedge = el('path', { d: arcPath(a + gap, a1 - gap), fill: sg.color, class: 'dn-seg' }, svg);
      wedge.addEventListener('mouseenter', (e) => { wedge.setAttribute('opacity', '.82'); Tip() && Tip().show(`<div class="tip-h"><b>${sg.label}</b></div><div class="tip-rows"><div><span></span><b>${sg.value} · ${Math.round(frac * 100)}%</b></div></div>`, e); });
      wedge.addEventListener('mousemove', (e) => Tip() && Tip().move(e));
      wedge.addEventListener('mouseleave', () => { wedge.setAttribute('opacity', '1'); Tip() && Tip().hide(); });
      a = a1;
    });
    if (o.center) { const fo = el('text', { x: cx, y: cx - 2, 'text-anchor': 'middle', class: 'dn-c-n' }, svg); fo.textContent = o.center; if (o.centerSub) { const fs = el('text', { x: cx, y: cx + 14, 'text-anchor': 'middle', class: 'dn-c-s' }, svg); fs.textContent = o.centerSub; } }
    return svg;
  }

  /* ============================================================
     HISTOGRAM  (score distribution)
     ============================================================ */
  function histogram(container, bins, opts) {
    container.innerHTML = '';
    const o = Object.assign({ color: 'var(--signal)', xlabels: null, height: null }, opts || {});
    const W = container.clientWidth || 480, H = o.height || container.clientHeight || 160;
    const m = { t: 10, r: 8, b: 22, l: 8 };
    const pw = W - m.l - m.r, ph = H - m.t - m.b;
    const n = bins.length, max = Math.max(...bins, 1);
    const gap = 4, bw = (pw - gap * (n - 1)) / n;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'hg-svg' });
    container.appendChild(svg);
    bins.forEach((v, i) => {
      const bh = Math.max(1, (v / max) * ph), x = m.l + i * (bw + gap), y = m.t + ph - bh;
      const t = i / (n - 1);
      const fill = `color-mix(in oklab, var(--signal) ${Math.round(22 + t * 60)}%, var(--surface-1))`;
      const g = el('g', { class: 'bc-bar' }, svg);
      el('rect', { x, y, width: bw, height: bh, rx: 3, fill }, g);
      reveal(g, [{ transform: 'scaleY(0)' }, { transform: 'none' }], i);
      if (o.xlabels && (i % 2 === 0)) { const tx = el('text', { x: x + bw / 2, y: H - 7, class: 'lc-axis', 'text-anchor': 'middle' }, svg); tx.textContent = o.xlabels[i]; }
    });
    return svg;
  }

  /* ============================================================
     CALIBRATION CURVE  (Analytics — predicted vs observed)
     ============================================================ */
  function calibration(container, pts, opts) {
    container.innerHTML = '';
    const o = Object.assign({ height: null }, opts || {});
    const W = container.clientWidth || 360, H = o.height || container.clientHeight || 300;
    const m = { t: 14, r: 14, b: 28, l: 32 };
    const pw = W - m.l - m.r, ph = H - m.t - m.b;
    const X = (v) => m.l + v * pw, Y = (v) => m.t + (1 - v) * ph;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'cal-svg' });
    container.appendChild(svg);
    [0, .25, .5, .75, 1].forEach((g) => { el('line', { x1: X(g), y1: m.t, x2: X(g), y2: m.t + ph, stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg); el('line', { x1: m.l, y1: Y(g), x2: m.l + pw, y2: Y(g), stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg); });
    // ideal diagonal
    el('line', { x1: X(0), y1: Y(0), x2: X(1), y2: Y(1), stroke: 'var(--text-tertiary)', 'stroke-width': 1.4, 'stroke-dasharray': '5 4' }, svg);
    // calibration line
    const P = pts.map((p) => [X(p.x), Y(p.y)]);
    el('path', { d: smoothPath(P), fill: 'none', stroke: 'var(--signal)', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, svg);
    pts.forEach((p, i) => { const g = el('g', { class: 'sc-pt', style: `--d:${i * 40}ms` }, svg); const dot = el('circle', { cx: X(p.x), cy: Y(p.y), r: 4, fill: 'var(--signal)', stroke: 'var(--surface-1)', 'stroke-width': 1.5 }, g); dot.addEventListener('mouseenter', (e) => Tip() && Tip().show(`<div class="tip-rows"><div><span>${o.xLab || 'Predicted'}</span><b>${Math.round(p.x * 100)}%</b></div><div><span>${o.yLab || 'Observed'}</span><b>${Math.round(p.y * 100)}%</b></div></div>`, e)); dot.addEventListener('mousemove', (e) => Tip() && Tip().move(e)); dot.addEventListener('mouseleave', () => Tip() && Tip().hide()); });
    const ax = el('text', { x: m.l + pw / 2, y: H - 6, class: 'radar-axis', 'text-anchor': 'middle' }, svg); ax.textContent = (o.xLab || 'Predicted') + ' →';
    const ay = el('text', { x: 8, y: m.t + ph / 2, class: 'radar-axis', 'text-anchor': 'middle', transform: `rotate(-90 8 ${m.t + ph / 2})` }, svg); ay.textContent = (o.yLab || 'Observed') + ' →';
    return svg;
  }

  /* ============================================================
     RADAR / SPIDER  (multi-axis profile, comparator)
     axes: [labels], series: [{ name, color, values:[0..100] }]
     ============================================================ */
  function spider(container, axes, series, opts) {
    container.innerHTML = '';
    const o = Object.assign({ size: null }, opts || {});
    const W = container.clientWidth || 320, H = o.size || container.clientHeight || 300;
    const cx = W / 2, cy = H / 2 + 4, R = Math.min(W, H) / 2 - 32;
    const N = axes.length;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'sp-svg' });
    container.appendChild(svg);
    const ang = (i) => -Math.PI / 2 + (i / N) * Math.PI * 2;
    const pt = (i, r) => [cx + Math.cos(ang(i)) * R * r, cy + Math.sin(ang(i)) * R * r];
    [0.25, 0.5, 0.75, 1].forEach((r) => {
      let d = '';
      for (let i = 0; i < N; i++) { const [x, y] = pt(i, r); d += (i ? 'L' : 'M') + x + ',' + y; }
      el('path', { d: d + 'Z', fill: 'none', stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg);
    });
    for (let i = 0; i < N; i++) { const [x, y] = pt(i, 1); el('line', { x1: cx, y1: cy, x2: x, y2: y, stroke: 'var(--border-subtle)', 'stroke-width': 1 }, svg); const [lx, ly] = pt(i, 1.16); const tx = el('text', { x: lx, y: ly + 3, class: 'sp-axis', 'text-anchor': lx < cx - 5 ? 'end' : lx > cx + 5 ? 'start' : 'middle' }, svg); tx.textContent = axes[i]; }
    series.forEach((s, si) => {
      let d = '';
      const pts = s.values.map((v, i) => pt(i, clamp(v, 0, 100) / 100));
      pts.forEach(([x, y], i) => { d += (i ? 'L' : 'M') + x + ',' + y; });
      const poly = el('path', { d: d + 'Z', fill: s.color, 'fill-opacity': s.ghost ? '0' : '.14', stroke: s.color, 'stroke-width': s.ghost ? 1.4 : 2, 'stroke-dasharray': s.ghost ? '4 3' : '', class: 'sp-poly' }, svg);
      reveal(poly, [{ opacity: 0, transform: 'scale(.6)' }, { opacity: 1, transform: 'none' }], si);
      if (!s.ghost) pts.forEach(([x, y]) => el('circle', { cx: x, cy: y, r: 2.6, fill: s.color }, svg));
    });
    return svg;
  }

  window.ChartsX = { lineChart, barChart, divergingArea, scatter, donut, histogram, calibration, spider };
})();
