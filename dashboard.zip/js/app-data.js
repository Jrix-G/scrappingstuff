/* ============================================================
   TANDOR — app-data.js
   Demo dataset mapped to the JSON contract + i18n + helpers.
   All numbers are illustrative placeholders.
   ============================================================ */
(function () {
  'use strict';

  /* ---------- small helpers ---------- */
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const round = Math.round;
  // deterministic pseudo-random from a string seed (stable across reloads)
  function seeded(seed) {
    let h = 1779033703 ^ seed.length;
    for (let i = 0; i < seed.length; i++) {
      h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
      h = (h << 13) | (h >>> 19);
    }
    return function () {
      h = Math.imul(h ^ (h >>> 16), 2246822507);
      h = Math.imul(h ^ (h >>> 13), 3266489909);
      h ^= h >>> 16;
      return (h >>> 0) / 4294967296;
    };
  }

  /* ---------- phases ---------- */
  const PHASES = {
    EMERGENT:     { en: 'Emergent',     fr: 'Émergent',     v: 'ph-emergent' },
    EARLY_GROWTH: { en: 'Early growth', fr: 'Début crois.', v: 'ph-early' },
    GROWTH:       { en: 'Growth',       fr: 'Croissance',   v: 'ph-growth' },
    MATURE:       { en: 'Mature',       fr: 'Mature',       v: 'ph-mature' },
    PEAK:         { en: 'Peak',         fr: 'Pic',          v: 'ph-peak' },
    DECLINING:    { en: 'Declining',    fr: 'En déclin',    v: 'ph-decline' },
  };

  const VERDICTS = {
    BUY:   { en: 'Buy',   fr: 'Acheter',    v: 'buy' },
    WATCH: { en: 'Watch', fr: 'Surveiller', v: 'watch' },
    PASS:  { en: 'Pass',  fr: 'Passer',     v: 'pass' },
  };

  const CATS = {
    WELLNESS: { en: 'Wellness',   fr: 'Bien-être' },
    HOME:     { en: 'Home',       fr: 'Maison' },
    TECH:     { en: 'Tech',       fr: 'Tech' },
    BEAUTY:   { en: 'Beauty',     fr: 'Beauté' },
    PETS:     { en: 'Pets',       fr: 'Animaux' },
    OUTDOOR:  { en: 'Outdoor',    fr: 'Plein air' },
    KITCHEN:  { en: 'Kitchen',    fr: 'Cuisine' },
    FITNESS:  { en: 'Fitness',    fr: 'Fitness' },
    APPAREL:  { en: 'Apparel',    fr: 'Mode' },
    BABY:     { en: 'Baby',       fr: 'Bébé' },
  };

  /* hue per category — used to tint thumbnail placeholders */
  const CAT_HUE = {
    WELLNESS: 175, HOME: 40, TECH: 250, BEAUTY: 330, PETS: 95,
    OUTDOOR: 145, KITCHEN: 25, FITNESS: 200, APPAREL: 300, BABY: 355,
  };

  /* ---------- build one product from compact base ---------- */
  function build(base) {
    const rnd = seeded(base.id);
    const gross = +(base.retail - base.cost).toFixed(2);
    const margin_pct = gross / base.retail;
    const tandor = round(0.55 * base.organic + 0.45 * base.sellability);
    // growth score: map monthly_growth [-0.5 .. +1.5] → 0..100
    const growthScore = round(clamp((base.growth + 0.5) / 2.0, 0, 1) * 100);
    // risk: low confidence OR high volatility OR no sellers → risk up
    let riskN = 0;
    if (base.confidence < 0.6) riskN += 1.4;
    if (base.confidence < 0.45) riskN += 1;
    if (base.volatility > 0.6) riskN += 1.2;
    if (base.listed === 0) riskN += 1.5;
    if (base.listed > 70) riskN += 0.6;
    const risk = riskN >= 2.2 ? 'high' : riskN >= 1 ? 'mod' : 'low';

    // momentum (0..100) for radar: velocity + acceleration blend
    const momentum = round(clamp(growthScore * 0.7 + base.organic * 0.3, 0, 100));
    // maturity (0..100): saturation proxy from listed sellers + age
    const maturity = round(clamp(base.listed * 0.7 + (base.age / 120) * 30, 0, 100));

    /* time series (procedural, stable) */
    const trend = series(base.organic, base.growth, base.volatility, 30, rnd, 8, 96);
    const reddit = series(base.redditScore, base.growth * 0.9, base.volatility * 1.2, 12, rnd, 2, 40, true);
    const cj = ramp(Math.max(1, base.listed - round(base.growth * 14)), base.listed, 12, rnd);

    return Object.assign({}, base, {
      gross, margin_pct, tandor, growthScore, risk, momentum, maturity,
      catHue: CAT_HUE[base.cat], trend, reddit, cj,
    });
  }

  // smooth-ish rising series ending near `level`
  function series(level, growth, vol, n, rnd, lo, hi, integer) {
    const out = [];
    const start = clamp(level - growth * 38, 4, 92);
    for (let i = 0; i < n; i++) {
      const f = i / (n - 1);
      // ease the rise
      const base = start + (level - start) * Math.pow(f, 1 - clamp(growth, 0, 0.8) * 0.5);
      const noise = (rnd() - 0.5) * vol * 18;
      let v = clamp(base + noise, lo, hi);
      out.push(integer ? Math.max(0, round(v / 6)) : +v.toFixed(1));
    }
    return out;
  }
  function ramp(from, to, n, rnd) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const f = i / (n - 1);
      out.push(round(from + (to - from) * f + (rnd() - 0.5) * 2));
    }
    return out;
  }

  /* ---------- compact base records ----------
     id, name, cat, cost, retail, sellability, organic, phase, verdict,
     growth(monthly, frac), confidence, listed, age(days), volatility,
     net (net after cpa €/sale), redditScore, trendsScore, seasonPeak(1-12),
     seasonMult(current month), reason{en,fr}, detectedHrs (for feed order)
  ----------------------------------------------------------------- */
  const BASE = [
    { id: 'CJ-4471', name: 'Cervical Neck Massager', cat: 'WELLNESS', cost: 6.4, retail: 34.9, sellability: 88, organic: 91, phase: 'EARLY_GROWTH', verdict: 'BUY', growth: 0.61, confidence: 0.82, listed: 14, age: 38, volatility: 0.28, net: 18.2, redditScore: 86, trendsScore: 79, seasonPeak: 11, seasonMult: 1.18, detectedHrs: 2,
      reason: { en: 'Reddit discussion spiked +240% with thin supplier saturation — strong organic lead before ads.', fr: 'Discussions Reddit +240 % avec une faible saturation fournisseurs — forte avance organique avant les pubs.' } },
    { id: 'CJ-7782', name: 'Sunset Projection Lamp', cat: 'HOME', cost: 3.1, retail: 24.0, sellability: 71, organic: 77, phase: 'GROWTH', verdict: 'WATCH', growth: 0.34, confidence: 0.74, listed: 41, age: 64, volatility: 0.31, net: 9.8, redditScore: 58, trendsScore: 74, seasonPeak: 12, seasonMult: 1.22, detectedHrs: 5,
      reason: { en: 'Steady Google Trends climb but seller count rising — window narrowing.', fr: 'Montée régulière sur Google Trends mais le nombre de vendeurs augmente — fenêtre qui se réduit.' } },
    { id: 'CJ-1130', name: 'Lint Shaver Pro', cat: 'APPAREL', cost: 2.2, retail: 19.9, sellability: 84, organic: 88, phase: 'EARLY_GROWTH', verdict: 'BUY', growth: 0.52, confidence: 0.8, listed: 9, age: 27, volatility: 0.24, net: 11.4, redditScore: 72, trendsScore: 81, seasonPeak: 10, seasonMult: 1.05, detectedHrs: 7,
      reason: { en: 'High margin, very low saturation, accelerating organic mentions across two sources.', fr: 'Forte marge, très faible saturation, mentions organiques en accélération sur deux sources.' } },
    { id: 'CJ-9021', name: 'Portable Mini Printer', cat: 'TECH', cost: 11.5, retail: 39.0, sellability: 44, organic: 38, phase: 'MATURE', verdict: 'PASS', growth: -0.08, confidence: 0.66, listed: 78, age: 142, volatility: 0.22, net: 4.1, redditScore: 21, trendsScore: 34, seasonPeak: 12, seasonMult: 0.98, detectedHrs: 11,
      reason: { en: 'Saturated supply and flat demand — past its window.', fr: 'Offre saturée et demande stable — fenêtre dépassée.' } },
    { id: 'CJ-3344', name: 'LED Dog Collar', cat: 'PETS', cost: 2.8, retail: 22.5, sellability: 79, organic: 83, phase: 'EMERGENT', verdict: 'BUY', growth: 0.74, confidence: 0.69, listed: 6, age: 16, volatility: 0.42, net: 12.9, redditScore: 80, trendsScore: 64, seasonPeak: 11, seasonMult: 1.12, detectedHrs: 1,
      reason: { en: 'Earliest-stage spike — very few sellers, fast Reddit acceleration. Higher risk, highest upside.', fr: 'Pic au stade le plus précoce — très peu de vendeurs, accélération Reddit rapide. Plus risqué, fort potentiel.' } },
    { id: 'CJ-5567', name: 'Magnetic Phone Mount', cat: 'TECH', cost: 1.9, retail: 16.9, sellability: 62, organic: 55, phase: 'MATURE', verdict: 'WATCH', growth: 0.12, confidence: 0.78, listed: 63, age: 110, volatility: 0.18, net: 6.0, redditScore: 40, trendsScore: 49, seasonPeak: 6, seasonMult: 1.0, detectedHrs: 14,
      reason: { en: 'Reliable evergreen but crowded — only worth it at scale.', fr: 'Valeur sûre mais encombrée — rentable seulement à grande échelle.' } },
    { id: 'CJ-2289', name: 'Heatless Curling Rod', cat: 'BEAUTY', cost: 1.4, retail: 18.0, sellability: 81, organic: 86, phase: 'GROWTH', verdict: 'BUY', growth: 0.48, confidence: 0.83, listed: 33, age: 52, volatility: 0.26, net: 10.6, redditScore: 75, trendsScore: 88, seasonPeak: 12, seasonMult: 1.15, detectedHrs: 4,
      reason: { en: 'Trends and Reddit corroborate; margin healthy at impulse price point.', fr: 'Trends et Reddit se corroborent ; marge saine à un prix d’impulsion.' } },
    { id: 'CJ-6610', name: 'Collapsible Water Bottle', cat: 'OUTDOOR', cost: 2.6, retail: 21.0, sellability: 66, organic: 60, phase: 'GROWTH', verdict: 'WATCH', growth: 0.27, confidence: 0.71, listed: 47, age: 73, volatility: 0.3, net: 7.2, redditScore: 48, trendsScore: 58, seasonPeak: 6, seasonMult: 1.28, detectedHrs: 9,
      reason: { en: 'Seasonal tailwind approaching peak month; supply moderate.', fr: 'Vent saisonnier favorable proche du mois de pic ; offre modérée.' } },
    { id: 'CJ-8843', name: 'Silicone Baby Bib', cat: 'BABY', cost: 1.1, retail: 14.9, sellability: 74, organic: 70, phase: 'EARLY_GROWTH', verdict: 'BUY', growth: 0.41, confidence: 0.77, listed: 19, age: 34, volatility: 0.27, net: 8.4, redditScore: 64, trendsScore: 61, seasonPeak: 5, seasonMult: 1.04, detectedHrs: 6,
      reason: { en: 'Repeat-purchase category with low saturation and steady climb.', fr: 'Catégorie à rachat fréquent, faible saturation et montée régulière.' } },
    { id: 'CJ-1907', name: 'Posture Corrector Belt', cat: 'FITNESS', cost: 3.0, retail: 27.0, sellability: 77, organic: 79, phase: 'GROWTH', verdict: 'BUY', growth: 0.39, confidence: 0.79, listed: 38, age: 58, volatility: 0.25, net: 11.0, redditScore: 69, trendsScore: 72, seasonPeak: 1, seasonMult: 1.31, detectedHrs: 8,
      reason: { en: 'New-year fitness seasonality building; strong cross-source signal.', fr: 'Saisonnalité fitness de début d’année qui monte ; signal multi-sources fort.' } },
    { id: 'CJ-2741', name: 'Acupressure Mat Set', cat: 'WELLNESS', cost: 5.2, retail: 33.0, sellability: 73, organic: 75, phase: 'GROWTH', verdict: 'WATCH', growth: 0.31, confidence: 0.72, listed: 44, age: 80, volatility: 0.29, net: 9.1, redditScore: 57, trendsScore: 66, seasonPeak: 1, seasonMult: 1.2, detectedHrs: 13,
      reason: { en: 'Decent margin, building demand, but competition climbing fast.', fr: 'Marge correcte, demande en hausse, mais concurrence qui grimpe vite.' } },
    { id: 'CJ-3380', name: 'Mushroom Night Light', cat: 'HOME', cost: 1.7, retail: 17.5, sellability: 80, organic: 84, phase: 'EMERGENT', verdict: 'BUY', growth: 0.69, confidence: 0.67, listed: 7, age: 19, volatility: 0.4, net: 9.9, redditScore: 78, trendsScore: 60, seasonPeak: 12, seasonMult: 1.1, detectedHrs: 3,
      reason: { en: 'Aesthetic viral format emerging on social; almost no sellers yet.', fr: 'Format esthétique viral émergent sur le social ; presque aucun vendeur.' } },
    { id: 'CJ-4456', name: 'Stainless Straw Kit', cat: 'KITCHEN', cost: 0.9, retail: 12.9, sellability: 58, organic: 47, phase: 'DECLINING', verdict: 'PASS', growth: -0.21, confidence: 0.7, listed: 84, age: 168, volatility: 0.2, net: 3.4, redditScore: 18, trendsScore: 28, seasonPeak: 7, seasonMult: 0.92, detectedHrs: 20,
      reason: { en: 'Fading interest and very high saturation.', fr: 'Intérêt en baisse et saturation très élevée.' } },
    { id: 'CJ-7120', name: 'Car Headrest Hook', cat: 'TECH', cost: 0.7, retail: 11.9, sellability: 64, organic: 56, phase: 'MATURE', verdict: 'WATCH', growth: 0.09, confidence: 0.75, listed: 58, age: 122, volatility: 0.17, net: 5.3, redditScore: 33, trendsScore: 44, seasonPeak: 12, seasonMult: 1.02, detectedHrs: 17,
      reason: { en: 'Cheap evergreen add-on; thin but consistent.', fr: 'Petit accessoire évergreen ; marge fine mais constante.' } },
    { id: 'CJ-9988', name: 'Pet Hair Remover Roller', cat: 'PETS', cost: 2.0, retail: 19.0, sellability: 76, organic: 73, phase: 'EARLY_GROWTH', verdict: 'BUY', growth: 0.44, confidence: 0.78, listed: 22, age: 41, volatility: 0.26, net: 9.6, redditScore: 66, trendsScore: 63, seasonPeak: 4, seasonMult: 1.06, detectedHrs: 10,
      reason: { en: 'Practical pet niche, low saturation, steady organic growth.', fr: 'Niche animaux pratique, faible saturation, croissance organique régulière.' } },
    { id: 'CJ-6033', name: 'Mini Vacuum Cleaner', cat: 'TECH', cost: 4.3, retail: 26.0, sellability: 60, organic: 52, phase: 'MATURE', verdict: 'WATCH', growth: 0.15, confidence: 0.73, listed: 55, age: 99, volatility: 0.21, net: 6.8, redditScore: 37, trendsScore: 47, seasonPeak: 11, seasonMult: 1.03, detectedHrs: 19,
      reason: { en: 'Gift-season uplift possible; otherwise crowded.', fr: 'Hausse possible en période cadeaux ; sinon encombré.' } },
    { id: 'CJ-2255', name: 'Gua Sha Stone Set', cat: 'BEAUTY', cost: 1.3, retail: 16.0, sellability: 78, organic: 81, phase: 'GROWTH', verdict: 'BUY', growth: 0.46, confidence: 0.81, listed: 36, age: 49, volatility: 0.24, net: 8.9, redditScore: 71, trendsScore: 83, seasonPeak: 12, seasonMult: 1.13, detectedHrs: 12,
      reason: { en: 'Beauty ritual trend with strong Trends signal and good margin.', fr: 'Tendance rituel beauté avec un fort signal Trends et une bonne marge.' } },
    { id: 'CJ-5519', name: 'Foldable Laptop Stand', cat: 'TECH', cost: 5.0, retail: 29.0, sellability: 67, organic: 59, phase: 'MATURE', verdict: 'WATCH', growth: 0.18, confidence: 0.76, listed: 51, age: 105, volatility: 0.19, net: 7.7, redditScore: 41, trendsScore: 50, seasonPeak: 9, seasonMult: 1.04, detectedHrs: 22,
      reason: { en: 'WFH evergreen; back-to-work bump in September.', fr: 'Évergreen télétravail ; rebond rentrée en septembre.' } },
    { id: 'CJ-8801', name: 'Reusable Makeup Pads', cat: 'BEAUTY', cost: 0.8, retail: 13.5, sellability: 69, organic: 64, phase: 'GROWTH', verdict: 'WATCH', growth: 0.24, confidence: 0.7, listed: 49, age: 77, volatility: 0.28, net: 6.6, redditScore: 45, trendsScore: 55, seasonPeak: 1, seasonMult: 1.05, detectedHrs: 16,
      reason: { en: 'Eco-angle demand rising; margin solid, competition moderate-high.', fr: 'Demande éco en hausse ; marge solide, concurrence modérée à élevée.' } },
    { id: 'CJ-3702', name: 'Electric Spin Scrubber', cat: 'HOME', cost: 6.9, retail: 36.0, sellability: 82, organic: 80, phase: 'EARLY_GROWTH', verdict: 'BUY', growth: 0.5, confidence: 0.79, listed: 24, age: 44, volatility: 0.25, net: 13.7, redditScore: 70, trendsScore: 76, seasonPeak: 3, seasonMult: 1.16, detectedHrs: 15,
      reason: { en: 'Spring-cleaning seasonality ahead; high net per sale, room to grow.', fr: 'Saisonnalité ménage de printemps à venir ; net élevé par vente, marge de progression.' } },
    { id: 'CJ-6644', name: 'Cloud Slippers', cat: 'APPAREL', cost: 2.4, retail: 21.9, sellability: 75, organic: 78, phase: 'GROWTH', verdict: 'BUY', growth: 0.43, confidence: 0.77, listed: 39, age: 56, volatility: 0.27, net: 10.1, redditScore: 67, trendsScore: 70, seasonPeak: 11, seasonMult: 1.09, detectedHrs: 18,
      reason: { en: 'Comfort-wear trend persists; strong impulse price and margin.', fr: 'Tendance confort persistante ; bon prix d’impulsion et marge.' } },
    { id: 'CJ-1284', name: 'Solar Garden Lights', cat: 'OUTDOOR', cost: 3.4, retail: 25.0, sellability: 63, organic: 57, phase: 'DECLINING', verdict: 'PASS', growth: -0.14, confidence: 0.68, listed: 72, age: 151, volatility: 0.23, net: 5.9, redditScore: 26, trendsScore: 39, seasonPeak: 6, seasonMult: 0.7, detectedHrs: 24,
      reason: { en: 'Out of season and saturated — revisit next spring.', fr: 'Hors saison et saturé — à revoir au printemps prochain.' } },
  ];

  const PRODUCTS = BASE.map(build);

  /* ---------- markets ---------- */
  const MARKETS = [
    { code: 'FR', flag: '🇫🇷', en: 'France', fr: 'France' },
    { code: 'EU', flag: '🇪🇺', en: 'Europe', fr: 'Europe' },
    { code: 'US', flag: '🇺🇸', en: 'United States', fr: 'États-Unis' },
    { code: 'UK', flag: '🇬🇧', en: 'United Kingdom', fr: 'Royaume-Uni' },
    { code: 'DE', flag: '🇩🇪', en: 'Germany', fr: 'Allemagne' },
    { code: 'WW', flag: '🌍', en: 'World', fr: 'Monde' },
  ];

  /* ---------- i18n strings ---------- */
  const STR = {
    en: {
      greeting: 'Good morning', sub_n: (n) => `${n} new opportunities detected since yesterday`,
      p_24h: '24h', p_7d: '7d', p_30d: '30d',
      kpi_active: 'Active opportunities', kpi_score: 'Market avg. score',
      kpi_margin: 'Median net margin', kpi_emerg: 'Emerging products',
      vs_prev: 'vs previous', this_period: 'this period',
      feed: 'Opportunity feed', feed_sub: 'Recent detections, newest first',
      champion: 'Champion of the day', detected: 'detected', ago: 'ago',
      hr: 'h', day: 'd', view_all: 'View all', growth_mo: '/mo',
      radar: 'Express radar', radar_sub: 'Momentum × maturity · last 20',
      q_emerg: 'Emergent · high potential', q_growth: 'Growing', q_sat: 'Saturated', q_avoid: 'Avoid',
      momentum: 'Momentum', maturity: 'Maturity',
      signals: 'Signals of the day', top_trends: 'Top Google Trends',
      top_reddit: 'Top Reddit velocity', top_corro: 'Strongest corroboration',
      corro_by: 'corroborated by', sources: 'sources',
      cat_dist: 'Category distribution', cat_sub: 'Buy verdicts by category · colour = avg score',
      season: 'Seasonality', season_sub: 'Demand multiplier · month × category',
      risk_low: 'Low risk', risk_mod: 'Moderate risk', risk_high: 'High risk',
      risk: 'Risk', conf: 'Confidence', score: 'Tandor score', verdict: 'Verdict',
      live: 'Data up to date', live_ago: '2h ago', live_pipeline: 'Pipeline status',
      run_cj: 'CJ catalogue', run_trends: 'Google Trends', run_reddit: 'Reddit',
      next_run: 'Next collection', in_min: 'in 41 min', ok: 'OK', limited: 'rate-limited',
      search_ph: 'Search a product, category, signal…',
      notif: 'Notifications', notif_unread: 'unread', mark_read: 'Mark all read',
      nav_disc: 'Discovery', nav_analysis: 'Analysis', nav_space: 'My space',
      n_home: 'Home', n_discovery: 'Product Discovery', n_radar: 'Opportunity Radar',
      n_trends: 'Trend Analysis', n_reddit: 'Reddit Intelligence', n_market: 'Market Signals', n_analytics: 'Analytics',
      n_saved: 'Saved', n_watch: 'Watchlists', n_alerts: 'Alerts',
      n_settings: 'Settings', n_billing: 'Billing', n_account: 'Account',
      plan: 'Scale', plan_usage: (a, b) => `${a} / ${b} products tracked`, upgrade: 'Upgrade',
      cmd_pages: 'Pages', cmd_products: 'Products', cmd_actions: 'Actions',
      a_new_watch: 'Create a watchlist', a_new_alert: 'Create an alert', a_export: 'Export today’s feed', a_toggle_theme: 'Toggle density',
      collapse: 'Collapse', soon: 'Coming soon', soon_msg: 'This page is on the roadmap — Dashboard Home is the live prototype.',
      saved_toast: 'Saved to your library', period_changed: 'Period',
      why: 'Why this score', open_detail: 'Open product dossier',
    },
    fr: {
      greeting: 'Bonjour', sub_n: (n) => `${n} nouvelles opportunités détectées depuis hier`,
      p_24h: '24h', p_7d: '7j', p_30d: '30j',
      kpi_active: 'Opportunités actives', kpi_score: 'Score moyen du marché',
      kpi_margin: 'Marge nette médiane', kpi_emerg: 'Produits émergents',
      vs_prev: 'vs période préc.', this_period: 'sur la période',
      feed: 'Flux d’opportunités', feed_sub: 'Détections récentes, les plus récentes d’abord',
      champion: 'Champion du jour', detected: 'détecté', ago: 'il y a',
      hr: 'h', day: 'j', view_all: 'Tout voir', growth_mo: '/mois',
      radar: 'Radar express', radar_sub: 'Momentum × maturité · 20 derniers',
      q_emerg: 'Émergent · fort potentiel', q_growth: 'En croissance', q_sat: 'Saturé', q_avoid: 'À éviter',
      momentum: 'Momentum', maturity: 'Maturité',
      signals: 'Signaux du jour', top_trends: 'Top Google Trends',
      top_reddit: 'Top vélocité Reddit', top_corro: 'Meilleure corroboration',
      corro_by: 'corroboré par', sources: 'sources',
      cat_dist: 'Répartition par catégorie', cat_sub: 'Verdicts Acheter par catégorie · couleur = score moyen',
      season: 'Saisonnalité', season_sub: 'Multiplicateur de demande · mois × catégorie',
      risk_low: 'Risque faible', risk_mod: 'Risque modéré', risk_high: 'Risque élevé',
      risk: 'Risque', conf: 'Confiance', score: 'Score Tandor', verdict: 'Verdict',
      live: 'Données à jour', live_ago: 'il y a 2 h', live_pipeline: 'État du pipeline',
      run_cj: 'Catalogue CJ', run_trends: 'Google Trends', run_reddit: 'Reddit',
      next_run: 'Prochaine collecte', in_min: 'dans 41 min', ok: 'OK', limited: 'limité',
      search_ph: 'Rechercher un produit, une catégorie, un signal…',
      notif: 'Notifications', notif_unread: 'non lues', mark_read: 'Tout marquer lu',
      nav_disc: 'Découverte', nav_analysis: 'Analyse', nav_space: 'Mon espace',
      n_home: 'Accueil', n_discovery: 'Product Discovery', n_radar: 'Opportunity Radar',
      n_trends: 'Analyse de tendances', n_reddit: 'Reddit Intelligence', n_market: 'Signaux marché', n_analytics: 'Analytics',
      n_saved: 'Sauvegardés', n_watch: 'Watchlists', n_alerts: 'Alertes',
      n_settings: 'Réglages', n_billing: 'Facturation', n_account: 'Compte',
      plan: 'Scale', plan_usage: (a, b) => `${a} / ${b} produits suivis`, upgrade: 'Upgrade',
      cmd_pages: 'Pages', cmd_products: 'Produits', cmd_actions: 'Actions',
      a_new_watch: 'Créer une watchlist', a_new_alert: 'Créer une alerte', a_export: 'Exporter le flux du jour', a_toggle_theme: 'Changer la densité',
      collapse: 'Replier', soon: 'Bientôt disponible', soon_msg: 'Cette page est sur la feuille de route — l’Accueil est le prototype actif.',
      saved_toast: 'Ajouté à votre bibliothèque', period_changed: 'Période',
      why: 'Pourquoi ce score', open_detail: 'Ouvrir le dossier produit',
    },
  };

  const MONTHS = {
    en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    fr: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'],
  };

  // seasonality matrix month×category (multiplier) — procedural from peak months
  function seasonMatrix() {
    const cats = ['WELLNESS', 'HOME', 'BEAUTY', 'TECH', 'FITNESS', 'OUTDOOR', 'PETS', 'KITCHEN'];
    const peaks = { WELLNESS: 11, HOME: 12, BEAUTY: 12, TECH: 12, FITNESS: 1, OUTDOOR: 6, PETS: 4, KITCHEN: 11 };
    return cats.map((c) => {
      const pk = peaks[c];
      const row = [];
      for (let m = 1; m <= 12; m++) {
        const d = Math.min(Math.abs(m - pk), 12 - Math.abs(m - pk));
        row.push(+(0.72 + 0.6 * Math.cos((d / 6) * Math.PI / 2)).toFixed(2));
      }
      return { cat: c, vals: row };
    });
  }

  window.TANDOR = {
    PRODUCTS, PHASES, VERDICTS, CATS, CAT_HUE, MARKETS, STR, MONTHS,
    seasonMatrix, clamp,
    // current month index (0-based) — June for the demo
    CUR_MONTH: 5,
  };
})();
