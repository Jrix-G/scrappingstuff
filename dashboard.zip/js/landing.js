/* ============================================================
   TANDOR — landing.js
   ============================================================ */
(function () {
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  // rAF is unreliable in offscreen iframes; setTimeout-based scheduler fires everywhere
  var RAF = function (cb) { return setTimeout(function () { cb(typeof performance !== "undefined" ? performance.now() : Date.now()); }, 16); };

  /* ---------- Nav scrolled state ---------- */
  var nav = $(".nav");
  function onScrollNav() {
    if (window.scrollY > 24) nav.classList.add("scrolled");
    else nav.classList.remove("scrolled");
  }
  onScrollNav();
  window.addEventListener("scroll", onScrollNav, { passive: true });

  /* ---------- Scroll reveals (rAF + getBoundingClientRect — robust in iframes) ---------- */
  var revEls = $$(".reveal, .reveal-scale, .reveal-x");
  function checkReveals() {
    var vh = window.innerHeight;
    for (var i = revEls.length - 1; i >= 0; i--) {
      var el = revEls[i];
      var r = el.getBoundingClientRect();
      if (r.top < vh * 0.92 && r.bottom > 0) {
        el.classList.add("in");
        (function (node) { setTimeout(function () { node.classList.add("shown"); }, 1150); })(el);
        if (el.dataset.onreveal && window[el.dataset.onreveal]) window[el.dataset.onreveal](el);
        revEls.splice(i, 1);
      }
    }
  }
  if (reduce) {
    revEls.forEach(function (el) {
      el.classList.add("in");
      if (el.dataset.onreveal && window[el.dataset.onreveal]) window[el.dataset.onreveal](el);
    });
    revEls = [];
  } else {
    window.addEventListener("scroll", checkReveals, { passive: true });
    window.addEventListener("resize", checkReveals, { passive: true });
    checkReveals();
    setTimeout(checkReveals, 60);
    setTimeout(checkReveals, 300);
    window.__revInit = true;
  }

  /* ---------- Parallax (hero halos) ---------- */
  var halos = $$(".hero-bg .halo");
  var stage = $(".signal-stage");
  var ticking = false;
  function parallax() {
    var y = window.scrollY;
    halos.forEach(function (h, i) {
      var sp = (i + 1) * 0.04;
      h.style.transform = "translateY(" + (y * sp) + "px)";
    });
    if (stage) {
      var cards = $$(".scard, .chip", stage);
      cards.forEach(function (c) {
        var d = parseFloat(c.dataset.depth || "0");
        c.style.setProperty("--py", (y * d * -0.05) + "px");
      });
    }
    ticking = false;
  }
  function reqParallax() { if (!ticking && !reduce) { ticking = true; RAF(parallax); } }
  window.addEventListener("scroll", reqParallax, { passive: true });

  /* ---------- Mouse parallax on hero signal stage ---------- */
  if (stage && !reduce) {
    var hero = $(".hero");
    hero.addEventListener("mousemove", function (e) {
      var r = hero.getBoundingClientRect();
      var mx = (e.clientX - r.left) / r.width - 0.5;
      var my = (e.clientY - r.top) / r.height - 0.5;
      $$(".scard, .chip", stage).forEach(function (c) {
        var d = parseFloat(c.dataset.depth || "1");
        c.style.setProperty("--mx", (mx * d * 22) + "px");
        c.style.setProperty("--my", (my * d * 18) + "px");
      });
    });
    hero.addEventListener("mouseleave", function () {
      $$(".scard, .chip", stage).forEach(function (c) {
        c.style.setProperty("--mx", "0px");
        c.style.setProperty("--my", "0px");
      });
    });
  }

  /* ---------- Dashboard 3D tilt on scroll ---------- */
  var browser = $(".browser");
  if (browser && !reduce) {
    var dashStage = $(".dash-stage");
    function tilt() {
      var r = dashStage.getBoundingClientRect();
      var vh = window.innerHeight;
      var prog = 1 - Math.max(0, Math.min(1, (r.top + r.height * 0.3) / vh));
      var rot = (1 - prog) * 12; // starts tilted, flattens
      browser.style.transform = "rotateX(" + rot.toFixed(2) + "deg) translateY(" + ((1 - prog) * 10) + "px)";
    }
    tilt();
    window.addEventListener("scroll", function () { RAF(tilt); }, { passive: true });
  }

  /* ---------- Velocity timeline draw ---------- */
  window.drawVelocity = function () {
    var chart = $(".velo-chart");
    if (!chart) return;
    var path = $(".velo-path", chart);
    if (path) {
      var len = path.getTotalLength();
      path.style.setProperty("--len", len);
      RAF(function () { path.classList.add("draw"); });
    }
    setTimeout(function () { var a = $(".velo-area", chart); if (a) a.classList.add("show"); }, 80);
    $$(".velo-bar", chart).forEach(function (b, i) {
      setTimeout(function () { b.classList.add("show"); }, 700 + i * 90);
    });
    $$(".velo-dot", chart).forEach(function (d) { setTimeout(function () { d.classList.add("show"); }, 1400); });
    setTimeout(function () { chart.classList.add("settled"); }, 2300);
    // count up footer numbers
    $$(".velo-foot .n[data-count]", chart).forEach(function (el) { countUp(el); });
  };

  /* ---------- Sparkbar reveal in features ---------- */
  window.growBars = function (root) {
    $$(".sparkbars i", root).forEach(function (b, i) {
      var h = b.dataset.h || "40";
      b.style.height = "0%";
      setTimeout(function () { b.style.transition = "height .7s cubic-bezier(.16,1,.3,1)"; b.style.height = h + "%"; }, i * 60);
      setTimeout(function () { b.style.transition = "none"; b.style.height = h + "%"; }, 1100 + i * 60);
    });
  };

  /* ---------- Count up ---------- */
  function countUp(el) {
    if (reduce) { el.textContent = el.dataset.count; return; }
    var target = parseFloat(el.dataset.count);
    var suffix = el.dataset.suffix || "";
    var prefix = el.dataset.prefix || "";
    var dec = (el.dataset.count.indexOf(".") > -1) ? 1 : 0;
    var start = null, dur = 1400;
    function step(t) {
      if (!start) start = t;
      var p = Math.min(1, (t - start) / dur);
      var e = 1 - Math.pow(1 - p, 3);
      el.textContent = prefix + (target * e).toFixed(dec).replace(".", ",") + suffix;
      if (p < 1) RAF(step);
    }
    RAF(step);
  }
  var countEls = $$("[data-count]").filter(function (el) { return !el.closest(".velo-foot"); });
  function checkCounts() {
    var vh = window.innerHeight;
    for (var i = countEls.length - 1; i >= 0; i--) {
      var el = countEls[i];
      var r = el.getBoundingClientRect();
      if (r.top < vh * 0.85 && r.bottom > 0) { countUp(el); countEls.splice(i, 1); }
    }
  }
  window.addEventListener("scroll", function () { RAF(checkCounts); }, { passive: true });
  RAF(checkCounts);
  setTimeout(checkCounts, 200);

  /* ---------- FAQ accordion ---------- */
  $$(".faq-item").forEach(function (item) {
    var q = $(".faq-q", item);
    var a = $(".faq-a", item);
    q.addEventListener("click", function () {
      var open = item.classList.contains("open");
      $$(".faq-item.open").forEach(function (o) { o.classList.remove("open"); $(".faq-a", o).style.maxHeight = null; });
      if (!open) { item.classList.add("open"); a.style.maxHeight = a.scrollHeight + "px"; }
    });
  });

  /* ---------- Pricing toggle ---------- */
  var priceBtns = $$(".price-toggle button");
  priceBtns.forEach(function (b) {
    b.addEventListener("click", function () {
      priceBtns.forEach(function (x) { x.classList.remove("on"); });
      b.classList.add("on");
      var yearly = b.dataset.period === "yearly";
      $$(".pcard .pprice .amt").forEach(function (a) {
        a.textContent = yearly ? a.dataset.y : a.dataset.m;
      });
      $$(".pcard .pprice .per").forEach(function (p) {
        p.setAttribute("data-fr", yearly ? "/mois · facturé annuel" : "/mois");
        p.setAttribute("data-en", yearly ? "/mo · billed yearly" : "/mo");
        applyLangTo(p);
      });
    });
  });

  /* ---------- Language toggle FR / EN ---------- */
  var lang = localStorage.getItem("tandor_lang") || "fr";
  function applyLangTo(el) {
    var v = el.getAttribute("data-" + lang);
    if (v !== null) {
      if (el.dataset.attr) el.setAttribute(el.dataset.attr, v);
      else el.innerHTML = v;
    }
  }
  function applyLang() {
    document.documentElement.lang = lang;
    $$("[data-fr]").forEach(applyLangTo);
    $$(".lang-toggle button").forEach(function (b) { b.classList.toggle("active", b.dataset.lang === lang); });
    // reset open FAQ heights
    $$(".faq-item.open .faq-a").forEach(function (a) { a.style.maxHeight = a.scrollHeight + "px"; });
  }
  $$(".lang-toggle button").forEach(function (b) {
    b.addEventListener("click", function () {
      lang = b.dataset.lang; localStorage.setItem("tandor_lang", lang); applyLang();
    });
  });
  applyLang();

  /* ---------- Hero variant switcher ---------- */
  var variant = localStorage.getItem("tandor_hero") || "1";
  function applyVariant() {
    $(".hero").setAttribute("data-variant", variant);
    $$(".variant-switch button").forEach(function (b) { b.classList.toggle("active", b.dataset.v === variant); });
  }
  $$(".variant-switch button").forEach(function (b) {
    b.addEventListener("click", function () {
      variant = b.dataset.v; localStorage.setItem("tandor_hero", variant); applyVariant();
    });
  });
  applyVariant();

  /* ---------- Smooth anchor + mobile ---------- */
  $$('a[href^="#"]').forEach(function (a) {
    a.addEventListener("click", function (e) {
      var id = a.getAttribute("href");
      if (id.length > 1) { var t = $(id); if (t) { e.preventDefault(); window.scrollTo({ top: t.getBoundingClientRect().top + window.scrollY - 70, behavior: reduce ? "auto" : "smooth" }); } }
    });
  });

  /* ---------- Mobile burger ---------- */
  var burger = $(".nav-burger");
  if (burger) {
    burger.addEventListener("click", function () { nav.classList.toggle("menu-open"); });
    $$(".nav-drawer a").forEach(function (a) { a.addEventListener("click", function () { nav.classList.remove("menu-open"); }); });
  }

  /* ---------- Year ---------- */
  var yr = $("#year"); if (yr) yr.textContent = new Date().getFullYear();
})();
