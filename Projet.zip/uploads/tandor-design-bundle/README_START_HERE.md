# Tandor — Bundle pour Claude Design

Commence par lire, dans l'ordre :
1. `CLAUDE_DESIGN_BRIEF.md`  → ta mission, le style à respecter, la liste des pages.
2. `DASHBOARD_SPEC.md`       → le cahier des charges UX/UI complet (source de vérité).
3. `frontend/src/`           → le code existant à prolonger SANS changer de style :
   - `Styles/base.css`, `Styles/sections.css` → tokens design + landing
   - `dashboard/app.css`, `dashboard/*.ts`     → dashboard (style, composants, i18n)
   - `Pages/*.tsx`                              → pages actuelles (Home = référence)
   - `public/index.html`                        → polices (Hanken Grotesk / JetBrains Mono / Instrument Serif)

`DESIGN_engine_optional.md` = algo (optionnel, pour comprendre le sens des scores).
